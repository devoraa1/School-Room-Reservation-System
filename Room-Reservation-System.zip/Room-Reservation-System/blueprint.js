// Building blueprint for the Rooms panel: floors, stairs and rooms, with
// each room's four time slots shown directly (green = open, orange =
// pending, red = booked) for the selected date. Clicking an open slot
// jumps to the Reserve form. script.js calls window.renderRoomBlueprint().
(function () {
    const FLOORS = [4, 3, 2, 1];
    const host = document.getElementById("roomBlueprint");
    if (!host) return;

    const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
    const ordinal = n => ["", "1ST", "2ND", "3RD", "4TH"][n] + " FLOOR";
    const STATUS = { available: "Available", pending: "Pending", approved: "Booked" };

    // "8:00–9:30 AM", "1:00–2:30 PM"
    function slotLabel(s) {
        const a = formatTime(s.start), b = formatTime(s.end);
        return (a.slice(-2) === b.slice(-2) ? a.slice(0, -3) : a) + "–" + b;
    }

    // Floor comes from the room's location text ("2nd Floor, ..."); Ground = 1st.
    function floorOf(r) {
        const m = /(\d+)\s*(?:st|nd|rd|th)/i.exec(r.location || "");
        return m ? Math.min(4, Math.max(1, +m[1])) : 1;
    }

    function render() {
        const date = document.getElementById("availabilityDate").value;
        const onlyOpen = document.getElementById("roomFilter").value === "available" && date;
        const isAdmin = currentUser.role === "admin";
        const byFloor = { 1: [], 2: [], 3: [], 4: [] };
        rooms.forEach(r => byFloor[floorOf(r)].push(r));

        const roomHtml = r => {
            let cls = "", slots;
            if (date) {
                const segs = getRoomSegments(r.id, date);
                const bookable = s => s.type === "available" && !isPastTimeToday(date, s.start);
                const free = segs.some(bookable);
                cls = free ? "is-open" : "is-full";
                if (onlyOpen && !free) cls += " is-dim";
                slots = segs.map((s, i) => s.type === "available" && !bookable(s)
                    ? `<div class="bp-slot none" title="This time has already started">${slotLabel(s)}</div>`
                    : s.type === "available"
                    ? `<button type="button" class="bp-slot available" title="Reserve ${esc(r.name)}, ${slotLabel(s)}"
                        onclick="reserveSlot(${r.id}, '${date}', ${i})">${slotLabel(s)}</button>`
                    : `<div class="bp-slot ${s.type}" title="${STATUS[s.type]}${s.purpose ? " · " + esc(s.purpose) : ""}">${slotLabel(s)}</div>`
                ).join("");
            } else {
                slots = TIME_SLOTS.map(t => `<div class="bp-slot none">${slotLabel(t)}</div>`).join("");
            }
            const admin = isAdmin
                ? `<span class="bp-admin"><button type="button" title="Edit room" onclick="editRoom(${r.id})">✏️</button>` +
                  `<button type="button" title="Remove room" onclick="deleteRoom(${r.id})">✕</button></span>`
                : "";
            return `<div class="bp-room ${cls}">${admin}<div class="bp-name">${esc(r.name)}</div>${slots}</div>`;
        };

        const floors = FLOORS.map(f => {
            const list = byFloor[f];
            const inner = list.length
                ? `<div class="bp-stairs">STAIRS</div>${list.map(roomHtml).join("")}<div class="bp-stairs">STAIRS</div>`
                : `<div class="bp-empty">EMPTY FLOOR</div>`;
            return `<div class="bp-floor"><div class="bp-label">${ordinal(f)}</div><div class="bp-space">${inner}</div></div>`;
        }).join("");

        host.innerHTML = `
            <div class="bp">
                <div class="bp-scroll">${floors}</div>
                <div class="bp-legend">
                    <span><i style="background:var(--ok)"></i>Open</span>
                    <span><i style="background:#fb923c"></i>Pending</span>
                    <span><i style="background:var(--danger)"></i>Booked</span>
                </div>
                <div class="bp-hint">${date ? "Click an open time to reserve it." : "Pick a date to see which times are open."}</div>
            </div>`;
    }

    window.renderRoomBlueprint = render;
    render();
})();
